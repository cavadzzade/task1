import CourseDetailsPage from './CourseDetailsPage';

export default CourseDetailsPage;
