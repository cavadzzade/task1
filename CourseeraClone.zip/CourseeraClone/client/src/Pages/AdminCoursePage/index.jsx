import AdminCoursePage from './AdminCoursePage';

export default AdminCoursePage;
