import AdminLogin from './AdminLogin';

export default AdminLogin;
