import AdminDashboard from './AdminDashboard';

export default AdminDashboard;
