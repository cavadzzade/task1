import { HomeCont1 } from './HomeCont1/HomeCont1';
import { HomeCont2 } from './HomeCont2/HomeCont2';
import { HomeCont3 } from './HomeCont3/HomeCont3';

export { HomeCont2, HomeCont1, HomeCont3 };
